/*************************************************************************
 * Name: Amanuel Ayalew                                                  **
 * Class: CSc 346                                                        **
 * Assignment: 4                                                         **
 * Due date: 04-02-25                                                    **
 * Instructor: Gamradt                                                   **
 * ***********************************************************************
 * Description: This interface defines a contract for reading graph     **
 * data from external storage. The method should be implemented using   **
 * JSON deserialization and include exception handling.                 **
 * **********************************************************************/

namespace GraphNS
{
    public interface IProcessData
    {
        /*************************************************************************
         * Method: ReadData                                                     **
         * Description: Reads graph data from a file using JSON. Should        **
         * check if the file exists and handle exceptions as needed.           **
         * **********************************************************************/
        void ReadData();
    }
}
