﻿/*************************************************************************
 * Name: Amanuel Ayalew                                                  **
 * Class: CSc 346                                                        **
 * Assignment: 4                                                         **
 * Due date: 04-02-25                                                    **
 * Instructor: Gamradt                                                   **
 * ***********************************************************************
 * Description: This is the driver program that creates a Graph object  **
 * using data from a JSON file and performs both Depth First and        **
 * Breadth First Search operations on the graph.                        **
 * **********************************************************************/

using System;
using GraphNS;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Graph Search Program");
        Console.WriteLine("--------------------");

        // Update this path to point to your actual JSON data file
        string filePath = "graphData.json";

        // Create graph instance
        Graph graph = new Graph(filePath);

        // Perform Depth First Search
        Console.WriteLine("\nDepth First Search:");
        graph.DepthFS();

        // Perform Breadth First Search
        Console.WriteLine("\nBreadth First Search:");
        graph.BreadthFS();

        Console.WriteLine("\nSearch complete.");
    }
}
