/*************************************************************************
 * Name: Amanuel Ayalew                                                  **
 * Class: CSc 346                                                        **
 * Assignment: 4                                                         **
 * Due date: 04-02-25                                                    **
 * Instructor: Gamradt                                                   **
 * ***********************************************************************
 * Description: This class represents a Graph that supports reading     **
 * data from a file and executing Depth First and Breadth First Search.**
 * Implements IProcessData and ISearchAlgorithms interfaces.            **
 * **********************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace GraphNS
{
    public class Graph : IProcessData, ISearchAlgorithms
    {
        private List<Node> _nodes;
        private string _filePath;

        private Stack<Node> _stack;
        private Queue<Node> _queue;

        /*************************************************************************
         * Constructor: Graph                                                   **
         * Description: Initializes the graph using a file path.               **
         * **********************************************************************/
        public Graph(string filePath)
        {
            _filePath = filePath;
            _nodes = new List<Node>();
            _stack = new Stack<Node>();
            _queue = new Queue<Node>();
            ReadData();
        }

        /*************************************************************************
         * Method: ReadData                                                     **
         * Description: Reads node data from JSON file using deserialization.  **
         * **********************************************************************/
        public void ReadData()
        {
            try
            {
                if (!File.Exists(_filePath))
                {
                    Console.WriteLine("File does not exist.");
                    return;
                }

                string jsonString = File.ReadAllText(_filePath);
                _nodes = JsonSerializer.Deserialize<List<Node>>(jsonString)!;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading file: {ex.Message}");
            }
        }

        /*************************************************************************
         * Method: Stack                                                        **
         * Description: Initializes the stack for DFS traversal.               **
         * **********************************************************************/
        public void Stack()
        {
            _stack = new Stack<Node>();
        }

        /*************************************************************************
         * Method: Queue                                                        **
         * Description: Initializes the queue for BFS traversal.               **
         * **********************************************************************/
        public void Queue()
        {
            _queue = new Queue<Node>();
        }

        /*************************************************************************
         * Method: DepthFS                                                      **
         * Description: Performs a Depth First Search traversal on the graph.  **
         * **********************************************************************/
        public void DepthFS()
        {
            Stack();
            ResetVisitedSet();

            Node start = _nodes[0];
            _stack.Push(start);
            start.WasVisited = true;
            ViewNode(start);

            while (_stack.Count > 0)
            {
                Node current = _stack.Peek();
                Node? neighbor = FindAdjacentUnvisitedNode(current);

                if (neighbor != null)
                {
                    neighbor.WasVisited = true;
                    ViewNode(neighbor);
                    _stack.Push(neighbor);
                }
                else
                {
                    _stack.Pop();
                }
            }

            Console.WriteLine(); // newline after traversal
            ResetVisitedSet();
        }

        /*************************************************************************
         * Method: BreadthFS                                                    **
         * Description: Performs a Breadth First Search traversal on the graph.**
         * **********************************************************************/
        public void BreadthFS()
        {
            Queue();
            ResetVisitedSet();

            Node start = _nodes[0];
            _queue.Enqueue(start);
            start.WasVisited = true;
            ViewNode(start);

            while (_queue.Count > 0)
            {
                Node current = _queue.Dequeue();
                Node? neighbor;

                while ((neighbor = FindAdjacentUnvisitedNode(current)) != null)
                {
                    neighbor.WasVisited = true;
                    ViewNode(neighbor);
                    _queue.Enqueue(neighbor);
                }
            }

            Console.WriteLine(); // newline after traversal
            ResetVisitedSet();
        }

        /*************************************************************************
         * Method: ResetVisitedSet                                              **
         * Description: Sets WasVisited to false for all nodes.                **
         * **********************************************************************/
        private void ResetVisitedSet()
        {
            foreach (var node in _nodes)
            {
                node.WasVisited = false;
            }
        }

        /*************************************************************************
         * Method: FindAdjacentUnvisitedNode                                    **
         * Description: Finds the first unvisited neighbor of a given node.    **
         * **********************************************************************/
        private Node? FindAdjacentUnvisitedNode(Node node)
        {
            foreach (int adjId in node.AdjacentNodes)
            {
                Node neighbor = _nodes.Find(n => n.Id == adjId)!;
                if (!neighbor.WasVisited)
                {
                    return neighbor;
                }
            }
            return null;
        }

        /*************************************************************************
         * Method: ViewNode                                                     **
         * Description: Prints the node ID followed by a space.                **
         * **********************************************************************/
        private void ViewNode(Node node)
        {
            Console.Write($"{node.Id} ");
        }
    }
}
