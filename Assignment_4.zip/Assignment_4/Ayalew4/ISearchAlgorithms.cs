/*************************************************************************
 * Name: Amanuel Ayalew                                                  **
 * Class: CSc 346                                                        **
 * Assignment: 4                                                         **
 * Due date: 04-02-25                                                    **
 * Instructor: Gamradt                                                   **
 * ***********************************************************************
 * Description: This interface defines the core search algorithms       **
 * required for graph traversal, including stack-based DFS and          **
 * queue-based BFS.                                                     **
 * **********************************************************************/

namespace GraphNS
{
    public interface ISearchAlgorithms
    {
        /*************************************************************************
         * Method: Stack                                                        **
         * Description: Initializes or manages stack logic for DFS.            **
         * **********************************************************************/
        void Stack();

        /*************************************************************************
         * Method: Queue                                                        **
         * Description: Initializes or manages queue logic for BFS.            **
         * **********************************************************************/
        void Queue();

        /*************************************************************************
         * Method: DepthFS                                                      **
         * Description: Executes the Depth First Search traversal.             **
         * **********************************************************************/
        void DepthFS();

        /*************************************************************************
         * Method: BreadthFS                                                    **
         * Description: Executes the Breadth First Search traversal.           **
         * **********************************************************************/
        void BreadthFS();
    }
}
