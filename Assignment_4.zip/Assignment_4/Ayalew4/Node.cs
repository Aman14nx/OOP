/*************************************************************************
 * Name: Amanuel Ayalew                                                  **
 * Class: CSc 346                                                        **
 * Assignment: 4                                                         **
 * Due date: 04-02-25                                                    **
 * Instructor: Gamradt                                                   **
 * ***********************************************************************
 * Description: This class represents a Node in a graph structure.      **
 * It holds an ID, visitation status, and a list of adjacent nodes.     **
 * **********************************************************************/

using System;
using System.Collections.Generic;

namespace GraphNS
{
    public class Node
    {
        // Properties
        public int Id { get; set; }
        public bool WasVisited { get; set; }
        public List<int> AdjacentNodes { get; set; }

        /*************************************************************************
         * Constructor: Node                                                    **
         * Description: Initializes a node with an ID and list of neighbors.   **
         * Input: int id, List<int> adjacentNodes                              **
         * **********************************************************************/
        public Node(int id, List<int> adjacentNodes)
        {
            Id = id;
            AdjacentNodes = adjacentNodes;
            WasVisited = false;
        }

        /*************************************************************************
         * Method: ToString                                                     **
         * Description: Returns a string with the node's ID.                   **
         * **********************************************************************/
        public override string ToString()
        {
            return Id.ToString();
        }
    }
}
